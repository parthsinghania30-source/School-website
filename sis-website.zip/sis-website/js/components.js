// Shared nav and footer injected by each page via innerHTML or manual copy
// This file is a reference — each HTML page has its own copy for static deployment

const NAV_HTML = `
<div class="top-bar">
  <div class="container">
    <div class="top-bar-links">
      <a href="#">CHILD PROTECTION</a>
      <a href="#">MANAGEBAC</a>
    </div>
    <div class="top-bar-social">
      <a href="#" title="Facebook">&#x1F426;</a>
      <a href="#" title="Instagram">&#128247;</a>
      <a href="#" title="LinkedIn">&#128100;</a>
      <a href="#" title="YouTube">&#127897;</a>
    </div>
  </div>
</div>
<header>
  <div class="container">
    <div class="nav-inner">
      <a href="index.html" class="logo">
        <div class="logo-icon">S</div>
        <div class="logo-text">
          <div class="school-name">SREENIDHI</div>
          <div class="school-sub">International School</div>
          <div class="tagline">Kindle the Light Within</div>
        </div>
      </a>
      <button class="menu-toggle" aria-label="Toggle menu">
        <span></span><span></span><span></span>
      </button>
      <nav>
        <ul>
          <li><a href="index.html">Home</a></li>
          <li class="nav-separator">|</li>
          <li><a href="about.html">About Us</a></li>
          <li class="nav-separator">|</li>
          <li><a href="leadership.html">Leadership Team</a></li>
          <li class="nav-separator">|</li>
          <li><a href="learning.html">Learning</a></li>
          <li class="nav-separator">|</li>
          <li><a href="student-life.html">Student Life</a></li>
          <li class="nav-separator">|</li>
          <li><a href="join-us.html">Join Us</a></li>
          <li class="nav-separator">|</li>
          <li><a href="contact.html">Contact Us</a></li>
        </ul>
      </nav>
    </div>
  </div>
</header>
`;
